# Cards

The Cards page is a common cards-based layout as seen in such apps as Facebook.

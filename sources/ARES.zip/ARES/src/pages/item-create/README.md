# Item Create

The Item Create Page creates new instances of `Item`, and will most commonly be used in a modal window to be presented by `ListMasterPage`.
